//
//  dbclass.swift
//  sqldemo
//
//  Created by TOPS on 9/6/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class dbclass: NSObject {

    
    func dml(query :String) -> Bool {
        
        var st :Bool = false;
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        let fullpath = path[0] ;
        
        let finalpath = fullpath.appending("/testios.db");
        
        print(finalpath);
        
        var op :OpaquePointer? = nil;
        
        
        if sqlite3_open(finalpath, &op) == SQLITE_OK {
            
            var stmt:OpaquePointer? = nil;
            
            if sqlite3_prepare_v2(op, query, -1, &stmt, nil) == SQLITE_OK {
                
                
                sqlite3_step(stmt);
                
                st = true;
                
                
                
            }
            
            sqlite3_finalize(stmt);
            
            sqlite3_close(op);
            
            
            
            
            
            
        }
        

        
        return st;
        
        
    }
    
    
    func getdata(query:String) -> [Any] {
        
        var arr:[Any] = [];
        
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        let fullpath = path[0] ;
        
        let finalpath = fullpath.appending("/testios.db");
        
        print(finalpath);
        
        var op :OpaquePointer? = nil;
        
        
        if sqlite3_open(finalpath, &op) == SQLITE_OK {
            
            var stmt:OpaquePointer? = nil;
            
            if sqlite3_prepare_v2(op, query, -1, &stmt, nil) == SQLITE_OK {
                
                
              
                while sqlite3_step(stmt) == SQLITE_ROW {
                    
                    
                    var temp:[String] = [];
                    
                    
                    var emp_id = String(cString: sqlite3_column_text(stmt, 0));
                      var emp_name = String(cString: sqlite3_column_text(stmt, 1));
                    
                      var emp_add = String(cString: sqlite3_column_text(stmt, 2));
                    temp.append(emp_id);
                    temp.append(emp_name);
                    temp.append(emp_add);
                    
                    
                    arr.append(temp)
                    
                    
                }
                
            }
            
            sqlite3_finalize(stmt);
            
            sqlite3_close(op);
            
            
            
            
            
            
        }
        
        
        
        return arr;
        
        
    }
}
