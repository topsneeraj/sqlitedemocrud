//
//  ViewController.swift
//  sqldemo
//
//  Created by TOPS on 9/6/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var tbl: UITableView!
    var arrfinal:[Any] = [];
    @IBOutlet weak var txtempid: UITextField!
    
    @IBOutlet weak var btn: UIButton!
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        getdata();
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func getdata()  {
        
        let db = dbclass();
        
        arrfinal = db.getdata(query: "select * from tblemp");
        
        print(arrfinal);
        tbl.reloadData();

        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return arrfinal.count;
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        return 3;
        
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        
        let temp = arrfinal[indexPath.section]  as! [String];
        
        cell.textLabel?.text = temp[indexPath.row];
        
        return cell;
        
        
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        
          let temp = arrfinal[indexPath.section]  as! [String];
        
        let emp_id = temp[0] ;
        
        let query = "delete from tblemp where emp_id =\(emp_id)";
        
        let db = dbclass();
        
        var st = db.dml(query: query);
        
         if st == true
         {
            
            
            arrfinal.remove(at: indexPath.section)
            tbl.reloadData();
            
        }
        
    }
    
    func clear()  {
        
        
        txtempid.text = "";
        txtempadd.text = "";
        txtempname.text = "";
    }
    @IBAction func btnclick(_ sender: Any) {
        
        
        if btn.titleLabel?.text == "insert" {
            
            
            let obj = dbclass();
            
            let strquery = "insert into tblemp(emp_id,emp_name,emp_add)values('\(txtempid.text!)','\(txtempname.text!)','\(txtempadd.text!)')";
            
            let st = obj.dml(query: strquery);
            
            
            if st == true {
                
                print("record inserted..");
                clear();
                getdata();
                txtempid.becomeFirstResponder();
                
                
            }
            else
            {
                print("not ");
                
            }
            
        }
        else
        {
            
            
            let obj = dbclass();
            
            let strquery = "update tblemp set emp_name ='\(txtempname.text!)',emp_add = '\(txtempadd.text!)' where emp_id = \(txtempid.text!)";
            
            let st = obj.dml(query: strquery);
            
            
            if st == true {
                
                print("record inserted..");
                clear();
                getdata();
                
                btn.setTitle("insert", for: .normal);
                txtempid.becomeFirstResponder()
                
            }
            else
            {
                print("not ");
                
            }
        }
        
       
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        
        let temp = arrfinal[indexPath.section]  as! [String];
        
        txtempid.text = temp[0];
        txtempname.text = temp[1];
        txtempadd.text = temp[2];
        
        txtempid.isUserInteractionEnabled = false;
        
        btn.setTitle("Update", for: .normal);
        
        
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

